/* =========================================================================
   二维码生成 · popup 逻辑
   1. 打开 popup 时读取当前标签页地址（activeTab 临时授权即可）
   2. 原样填入文本框并立即渲染，不等防抖
   3. 之后任何手动修改都走 220ms 防抖自动重绘
   ========================================================================= */
'use strict';

(function () {

  var $ = function (id) { return document.getElementById(id); };

  var textEl    = $('text');
  var counterEl = $('counter');
  var capEl     = $('capacity');
  var qrSvg     = $('qrsvg');
  var qrPath    = $('qrPath');
  var emptyEl   = $('empty');
  var emptyText = $('emptyText');
  var qrMeta    = $('qrMeta');
  var fixEcl    = $('fixEcl');
  var seg       = $('seg');
  var copyBtn   = $('copyBtn');
  var pngBtn    = $('pngBtn');
  var svgBtn    = $('svgBtn');
  var toastEl   = $('toast');
  var clearBtn  = $('clear');
  var openSite  = $('openSite');

  var SITE_URL = 'https://qr.yytech.top/';
  var QUIET = 4;               // 静区（module 数），与站点一致

  var ecl = 'M';
  var current = null;          // { result, text, view, svgString }
  var timer = null;
  var emptyHint = '输入内容后自动生成二维码';

  /* 浏览器内置页面 / 扩展页，读得到 URL 也没有分享意义 */
  var RESTRICTED = /^(chrome|edge|about|devtools|view-source|chrome-extension|moz-extension|opera|brave|vivaldi|chrome-search|chrome-untrusted|chrome-native|qqbrowser|se-extension|ext):/i;

  var ECL_ORDER_STRONG_TO_WEAK = ['H', 'Q', 'M', 'L'];

  /* ---------------- 提示 ---------------- */

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { toastEl.classList.remove('show'); }, 1800);
  }

  /* ---------------- 状态 ---------------- */

  function setEmpty(msg, opts) {
    opts = opts || {};
    current = null;
    emptyEl.hidden = false;
    document.querySelector('.plate').classList.add('is-empty');
    emptyEl.classList.toggle('err', !!opts.error);
    emptyText.textContent = msg || '';
    qrPath.setAttribute('d', '');
    qrMeta.textContent = '';
    if (opts.fix) {
      fixEcl.hidden = false;
      fixEcl.textContent = '改用 ' + opts.fix.ecl + ' 级（容量更大）';
      fixEcl.dataset.fixEcl = opts.fix.ecl;
    } else {
      fixEcl.hidden = true;
      fixEcl.dataset.fixEcl = '';
    }
    copyBtn.disabled = pngBtn.disabled = svgBtn.disabled = true;
  }

  function showQR(result, text) {
    var size = result.size, mod = result.modules, q = QUIET, d = [];
    for (var y = 0; y < size; y++) {
      var x = 0;
      while (x < size) {
        if (mod[y * size + x]) {
          var w = 1;
          while (x + w < size && mod[y * size + x + w]) w++;
          d.push('M' + (x + q) + ' ' + (y + q) + 'h' + w + 'v1h-' + w + 'z');
          x += w;
        } else {
          x++;
        }
      }
    }

    var view = size + q * 2;
    var pathD = d.join('');
    qrSvg.setAttribute('viewBox', '0 0 ' + view + ' ' + view);
    qrPath.setAttribute('d', pathD);

    emptyEl.hidden = true;
    document.querySelector('.plate').classList.remove('is-empty');
    qrMeta.textContent = '版本 ' + result.version + ' · ' + size + '×' + size +
                         ' · 容错 ' + result.ecl + ' · 掩码 ' + result.mask +
                         (result.version >= 25 ? ' · 码点较密，建议下载 PNG 再扫' : '');

    var svgString = '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<svg xmlns="http://www.w3.org/2000/svg" width="' + view * 12 + '" height="' + view * 12 +
      '" viewBox="0 0 ' + view + ' ' + view + '" shape-rendering="crispEdges">' +
      '<rect width="' + view + '" height="' + view + '" fill="#ffffff"/>' +
      '<path fill="#000000" d="' + pathD + '"/></svg>';

    current = { result: result, text: text, view: view, svgString: svgString };
    copyBtn.disabled = pngBtn.disabled = svgBtn.disabled = false;
  }

  /* ---------------- 渲染 ---------------- */

  function render() {
    if (typeof QR === 'undefined') {
      setEmpty('编码器没有加载成功，请重新加载扩展', { error: true });
      return;
    }

    var text = textEl.value;
    var bytes = QR.byteLength(text);
    var chars = Array.from(text).length;
    counterEl.textContent = chars + ' 字 / ' + bytes + ' 字节';

    if (text.trim() === '') {
      setEmpty(emptyHint);
      return;
    }

    try {
      showQR(QR.encode(text, ecl), text);
    } catch (e) {
      if (e && e.tooLong) {
        var max = QR.maxBytes(ecl);
        var alt = null;
        for (var i = 0; i < ECL_ORDER_STRONG_TO_WEAK.length; i++) {
          var lv = ECL_ORDER_STRONG_TO_WEAK[i];
          if (lv !== ecl && bytes <= QR.maxBytes(lv)) { alt = lv; break; }
        }
        setEmpty(
          '内容 ' + bytes + ' 字节，超出「' + ecl + '」级上限 ' + max + ' 字节' +
          (alt ? '' : '，请缩短内容'),
          { error: true, fix: alt ? { ecl: alt } : null }
        );
      } else {
        setEmpty('生成失败：' + ((e && e.message) || '未知错误'), { error: true });
      }
    }
  }

  function renderSoon() {
    clearTimeout(timer);
    timer = setTimeout(render, 220);
  }

  /* ---------------- 导出 ---------------- */

  function toCanvas() {
    var r = current.result, size = r.size, q = QUIET, mod = r.modules;
    var total = size + q * 2;
    var px = Math.max(4, Math.floor(1024 / total));
    var canvas = document.createElement('canvas');
    canvas.width = total * px;
    canvas.height = total * px;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#000000';
    for (var y = 0; y < size; y++) {
      for (var x = 0; x < size; x++) {
        if (mod[y * size + x]) ctx.fillRect((x + q) * px, (y + q) * px, px, px);
      }
    }
    return canvas;
  }

  function stamp() {
    var d = new Date();
    var p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' +
           p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
  }

  function download(blob, name) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  }

  function downloadPng() {
    if (!current) return;
    var name = 'qrcode-' + stamp() + '.png';
    toCanvas().toBlob(function (blob) {
      if (!blob) { toast('导出失败，请重试'); return; }
      download(blob, name);
      toast('已下载 PNG');
    }, 'image/png');
  }

  function downloadSvg() {
    if (!current) return;
    download(new Blob([current.svgString], { type: 'image/svg+xml;charset=utf-8' }),
             'qrcode-' + stamp() + '.svg');
    toast('已下载 SVG');
  }

  function copyPng() {
    if (!current) return;
    if (!navigator.clipboard || !window.ClipboardItem) {
      toast('当前环境不支持复制，已改为下载 PNG');
      downloadPng();
      return;
    }
    toCanvas().toBlob(function (blob) {
      if (!blob) { toast('复制失败，已改为下载 PNG'); downloadPng(); return; }
      navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
        .then(function () { toast('二维码已复制到剪贴板'); })
        .catch(function () { toast('复制失败，已改为下载 PNG'); downloadPng(); });
    }, 'image/png');
  }

  /* ---------------- 容错级别 ---------------- */

  function setEcl(level) {
    ecl = level;
    Array.prototype.forEach.call(seg.querySelectorAll('button'), function (b) {
      b.setAttribute('aria-pressed', b.dataset.ecl === level ? 'true' : 'false');
    });
    capEl.textContent = '最多 ' + QR.maxBytes(level) + ' 字节';
  }

  seg.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-ecl]');
    if (!b) return;
    setEcl(b.dataset.ecl);
    render();
  });

  fixEcl.addEventListener('click', function () {
    var lv = fixEcl.dataset.fixEcl;
    if (!lv) return;
    setEcl(lv);
    render();
  });

  /* ---------------- 输入 ---------------- */

  function autoGrow() {
    textEl.style.height = 'auto';
    textEl.style.height = Math.min(108, Math.max(58, textEl.scrollHeight)) + 'px';
  }

  textEl.addEventListener('input', function () {
    emptyHint = '输入内容后自动生成二维码';
    autoGrow();
    renderSoon();
  });

  textEl.addEventListener('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); render(); }
  });

  clearBtn.addEventListener('click', function () {
    textEl.value = '';
    emptyHint = '输入内容后自动生成二维码';
    autoGrow();
    render();
    textEl.focus();
  });

  copyBtn.addEventListener('click', copyPng);
  pngBtn.addEventListener('click', function (e) { e.preventDefault(); downloadPng(); });
  svgBtn.addEventListener('click', function (e) { e.preventDefault(); downloadSvg(); });

  openSite.addEventListener('click', function () {
    try {
      chrome.tabs.create({ url: SITE_URL });
    } catch (e) {
      /* 非扩展环境（本地预览）时忽略 */
    }
  });

  /* ---------------- 读取当前标签页地址 ---------------- */

  function readTabUrl() {
    return new Promise(function (resolve) {
      try {
        if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
          resolve({ url: '', reason: 'noapi' });
          return;
        }
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          var t = tabs && tabs[0];
          var url = (t && (t.url || t.pendingUrl)) || '';
          resolve({ url: url, reason: url ? '' : 'denied' });
        });
      } catch (e) {
        resolve({ url: '', reason: 'error' });
      }
    });
  }

  function init() {
    setEcl('M');
    setEmpty('正在读取页面地址…');

    readTabUrl().then(function (r) {
      var url = r.url || '';

      if (url && !RESTRICTED.test(url)) {
        textEl.value = url;               // 原样使用，不编码不解码不删参数
        autoGrow();
        render();                         // 立即出码，不等 220ms 防抖
        textEl.scrollTop = 0;             // 长网址从头显示
        return;
      }

      emptyHint = url
        ? '浏览器内置页面读不到地址，请手动输入'
        : '没有读到当前地址，请手动输入';
      textEl.value = '';
      autoGrow();
      render();
      textEl.focus();
    });
  }

  init();
})();
